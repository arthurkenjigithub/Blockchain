const Web3 = require("web3");
const web3 = new Web3("HTTP://127.0.0.1:8545");

const contractABI = [
  {
    "inputs": [
      {
        "internalType": "uint256",
        "name": "_estudante_id",
        "type": "uint256"
      },
      {
        "internalType": "string",
        "name": "_nome",
        "type": "string"
      },
      {
        "internalType": "string",
        "name": "_grau",
        "type": "string"
      }
    ],
    "name": "adicionarRegistro",
    "outputs": [],
    "stateMutability": "nonpayable",
    "type": "function"
  },
];

// Defina o endereço do contrato. Este deve ser um endereço real do contrato na blockchain.
const contractAddress = "EnderecoDoContrato";

// Crie uma instância do contrato
const academicRegistry = new web3.eth.Contract(contractABI, contractAddress);

// Função para adicionar um registro acadêmico
async function adicionarRegistro(estudante_id, nome, grau) {
  try {
    // Envia a transação para adicionar o registro acadêmico
    await academicRegistry.methods.adicionarRegistro(estudante_id, nome, grau).send({ from: ethereum.selectedAddress });
    console.log("Registro adicionado com sucesso!");
    return true;
  } catch (error) {
    console.error("Erro ao adicionar registro:", error);
    return false;
  }
}

// Função para visualizar registros
function verRegistros() {
  // Redireciona para a página onde os registros serão exibidos
  window.location.href = "Academic.html";
}

// Exporte as funções que serão usadas em outros arquivos, se necessário
module.exports = {
  adicionarRegistro,
  verRegistros
};
