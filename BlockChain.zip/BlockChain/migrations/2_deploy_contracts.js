const Academic = artifacts.require("Academic");


module.exports = function(deployer) {
  deployer.deploy(Academic);
};

